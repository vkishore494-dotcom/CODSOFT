import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
train_data = pd.read_csv("train_data.txt", sep=':::', engine='python', header=None)
train_data.columns = ['id', 'title', 'genre', 'plot']
test_data = pd.read_csv("test_data.txt", sep=':::', engine='python', header=None)
test_data.columns = ['id', 'title', 'plot']
test_labels = pd.read_csv("test_data_solution.txt", sep=':::', engine='python', header=None)
test_labels.columns = ['id', 'title', 'genre', 'plot']
train_data = train_data.dropna()
test_data = test_data.dropna()
test_labels = test_labels.dropna()
X_train = train_data['plot']
y_train = train_data['genre']
X_test = test_data['plot']
y_test = test_labels['genre']
vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)
nb_model = MultinomialNB()
nb_model.fit(X_train_vec, y_train)
lr_model = LogisticRegression(max_iter=1000)
lr_model.fit(X_train_vec, y_train)
nb_pred = nb_model.predict(X_test_vec)
lr_pred = lr_model.predict(X_test_vec)
print("\n Naive Bayes Results")
print("Accuracy:", accuracy_score(y_test, nb_pred))
print(classification_report(y_test, nb_pred))
print("\n Logistic Regression Results")
print("Accuracy:", accuracy_score(y_test, lr_pred))
print(classification_report(y_test, lr_pred))
sample_movies = [
    "A spaceship travels through space to save humanity",
    "A young couple falls in love in college",
    "A detective investigates a mysterious murder case",
    "A haunted house scares a group of teenagers"
]
print("\n Sample Predictions:")
for movie in sample_movies:
    vec = vectorizer.transform([movie])
    pred = lr_model.predict(vec)
    print(f"{movie} --> {pred[0]}")