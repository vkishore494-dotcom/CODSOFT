## Dataset
Dataset used: Movie Genre Classification Dataset
Download from:
https://www.kaggle.com/datasets/hijest/genre-classification-dataset-imdb