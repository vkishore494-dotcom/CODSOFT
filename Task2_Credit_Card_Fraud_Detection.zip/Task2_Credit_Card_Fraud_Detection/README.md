## Dataset

The dataset used for this project is publicly available on Kaggle:

🔗 https://www.kaggle.com/datasets/kartik2112/fraud-detection

Note:
Due to file size limitations, the dataset is not uploaded to this repository. 
Please download it from the above link and place the CSV file in the project directory before running the code.