import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

data = pd.read_csv("fraudTrain.csv")

data = data.drop(['Unnamed: 0', 'trans_date_trans_time', 'cc_num'], axis=1)

label_encoders = {}

for col in data.select_dtypes(include=['object', 'string']).columns:
    le = LabelEncoder()
    data[col] = le.fit_transform(data[col])
    label_encoders[col] = le

X = data.drop('is_fraud', axis=1)
y = data['is_fraud']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

sample = X_test.iloc[0:1]
prediction = model.predict(sample)

if prediction[0] == 1:
    print("\n⚠️ Fraudulent Transaction")
else:
    print("\n✅ Legitimate Transaction")