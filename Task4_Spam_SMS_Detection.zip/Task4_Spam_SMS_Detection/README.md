Spam SMS Detection

This project is developed as part of the CodSoft Machine Learning Internship.

Objective
The goal is to classify SMS messages as spam or ham using machine learning.

Tools Used
Python
Pandas
Scikit-learn

Algorithm
Multinomial Naive Bayes

Dataset
SMS Spam Collection Dataset

Result
The model successfully detects spam messages with high accuracy.